package com.rabbiter.hotel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.hotel.domain.Order;

public interface OrderMapper extends BaseMapper<Order> {
}
