package com.rabbiter.hotel.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rabbiter.hotel.domain.User;

public interface UserService extends IService<User> {

}
