<!--
 * @Description: 
 * @Author: Rabbiter
 * @Date: 2023-03-05 20:17:11
-->
### 启动项目
``` bash
# 切换镜像
npm config set registry https://registry.npm.taobao.org

# 安装依赖
npm install --force

# 更新依赖
npm update

# 启动项目
npm run dev
