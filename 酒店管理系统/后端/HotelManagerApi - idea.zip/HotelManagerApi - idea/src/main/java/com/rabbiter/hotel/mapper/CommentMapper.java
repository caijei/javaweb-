package com.rabbiter.hotel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.hotel.domain.Comment;

public interface CommentMapper extends BaseMapper<Comment> {
}
