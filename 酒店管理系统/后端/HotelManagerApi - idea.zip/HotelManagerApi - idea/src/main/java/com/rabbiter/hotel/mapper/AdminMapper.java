package com.rabbiter.hotel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.hotel.domain.Admin;

public interface AdminMapper extends BaseMapper<Admin> {
}
