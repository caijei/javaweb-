package com.rabbiter.hotel.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rabbiter.hotel.domain.Comment;

public interface CommentService extends IService<Comment> {
}
