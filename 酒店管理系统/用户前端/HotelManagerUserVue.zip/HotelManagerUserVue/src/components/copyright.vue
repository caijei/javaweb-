<template>
  <el-row>
    <el-col :span="24">
      <!-- <p>Copyright © 悲伤大白兔</p> -->
    </el-col>
  </el-row>
</template>

<script>
  export default {
    data() {
      return {}
    },
    methods: {

    },
  }
</script>

<style scoped="scoped">
  .el-row {
    min-height: 6vh;
    font-size: 1rem;
  }
  
  p {
    margin: 0.5rem;
  }
</style>
