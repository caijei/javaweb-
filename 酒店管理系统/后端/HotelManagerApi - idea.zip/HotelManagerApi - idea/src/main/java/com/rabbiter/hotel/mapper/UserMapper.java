package com.rabbiter.hotel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.hotel.domain.User;

public interface UserMapper extends BaseMapper<User> {


}
