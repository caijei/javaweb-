package com.rabbiter.hotel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.hotel.domain.Type;

public interface TypeMapper extends BaseMapper<Type> {
}
