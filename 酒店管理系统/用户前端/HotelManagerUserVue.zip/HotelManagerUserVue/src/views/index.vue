<template>
 <div>
    <el-container class="wrapper">
      <el-header class="header">Header</el-header>
      <el-main class="section">
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
        <p>页面很长怎么办</p>
      </el-main>
      <el-footer class="footer">
        <footbar></footbar>
      </el-footer>
    </el-container>
  </div>
<!--  <div class="wrapper">
    <div class="header">header</div>
    <div class="section">section</div>
    <div class="footer">footer</div>
  </div> -->
</template>

<script>
  import footbar from "@/components/footbar.vue";
  export default {
    data() {
      return {

      }
    },
    components: {
      footbar,
    },
    methods: {

    }
  }
</script>

<style scoped="scoped">
  
</style>
